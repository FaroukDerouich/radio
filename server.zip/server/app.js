const express =require("express");
const app = express();
const mongoose =require("mongoose");
app.use(express.json());
const cors=require("cors");
app.use(cors());

const mongoUrl ="mongodb+srv://farouk:eaWuOL3KeskKq9Y7@cluster0.gkx8avw.mongodb.net/?retryWrites=true&w=majority"
mongoose.connect(mongoUrl,{
    useNewUrlParser:true 
}).then(()=>{console.log("Connected to database");})
.catch((event)=> console.log(event));

app.listen(5001,()=> {
    console.log("Server started");
});

require("./dataDetails");
const Data = mongoose.model("DataInfo");

app.post("/registerData", async (req, res) => {
  const {
    nomSite,
    location,
    numPopulation,
    category,
    traficCs,
    traficPs,
    priceMin,
    priceGb
  } = req.body ;
  try {
    await Data.create({
      nomSite,
      location,
      numPopulation,
      category,
      traficCs,
      traficPs,
      priceMin,
      priceGb
    });
    res.send({ status: "ok" });
  } catch (error) {
    res.send({ status: "error" });
  }
});