const mongoose = require("mongoose");

const UserDetailsScehma = new mongoose.Schema(
  {
    nomSite :String,
    location: String,
    numPopulation : Number,
    category :String,
    traficCs:Number,
    traficPs: Number,
    priceMin: Number,
    priceGb: Number,
  },
  {
    collection: "DataInfo",
  }
);

mongoose.model("DataInfo", UserDetailsScehma);